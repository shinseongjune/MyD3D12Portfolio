#pragma once
#include <memory>
#include <vector>
#include <string>
#include "IAssetImporter.h"

class ImportRegistry
{
public:
    void Register(std::unique_ptr<IAssetImporter> importer);

    // ���� ��η� importer ����
    IAssetImporter* FindImporterForFile(const std::string& filePath) const;

    // Ȯ���� ���� ����
    IAssetImporter* FindImporterForExtensionLower(const std::string& extLower) const;

private:
    std::vector<std::unique_ptr<IAssetImporter>> m_importers;

    static std::string GetExtensionLower(const std::string& filePath);
};
