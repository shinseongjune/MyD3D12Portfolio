#pragma once
#include <cstdint>
#include <Windows.h>
#include <vector>

#include "RenderItem.h"
#include "UIDrawItem.h"
#include "RenderCamera.h"
#include "UITextDraw.h"
#include "FrameLights.h"

class IRenderer
{
public:
    virtual ~IRenderer() = default;

    virtual void Initialize(HWND hwnd, uint32_t width, uint32_t height) = 0;
    virtual void Resize(uint32_t width, uint32_t height) = 0;

    // ������ ����(��ο� ����Ʈ �ޱ�)
    virtual void Render(const std::vector<RenderItem>& items, const RenderCamera& cam, const FrameLights& lights, TextureHandle skybox, const std::vector<UIDrawItem>& ui, const std::vector<UITextDraw>& text) = 0;
    virtual void RenderUI(const std::vector<UIDrawItem>& ui) = 0;

    virtual void Shutdown() = 0;
};
