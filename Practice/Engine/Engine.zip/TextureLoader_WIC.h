#pragma once
#include <string>
#include "ImportTypes.h" // Result<T> ����
#include "TextureCPUData.h"

// path(UTF-16)�� �ε�
Result<TextureCpuData> LoadTextureRGBA8_WIC(
    const std::wstring& path,
    ImageColorSpace colorSpace = ImageColorSpace::SRGB,
    bool flipY = false);

// path(UTF-8)�� �ε� (AssetPipeline�� std::string ���� �� ����)
Result<TextureCpuData> LoadTextureRGBA8_WIC(
    const std::string& utf8Path,
    ImageColorSpace colorSpace = ImageColorSpace::SRGB,
    bool flipY = false);
