﻿#include <Windows.h>
#include "Application.h"

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE /*hPrevInstance*/,
    _In_ LPWSTR /*lpCmdLine*/,
    _In_ int /*nCmdShow*/)
{
    Application app;
    app.Initialize(hInstance);
    app.Run();
    app.Shutdown();
    return 0;
}
