#pragma once
#include <string>
#include <vector>

#include "World.h"
#include "AssetPipeline.h"
#include "MeshManager.h"
#include "TextureManager.h"
#include "SceneScope.h"
#include "ImportTypes.h"
#include "Utilities.h"
#include "Input.h"
#include "SoundManager.h"
#include "SoundImporterMF.h"
#include "SoundHandle.h"
#include "AudioSystem.h"
#include "AudioCommand.h"
#include "TextureHandle.h"
#include "UITextDraw.h"

class PhysicsSystem;

struct SceneContext
{
    World& world;
    AssetPipeline& assets;
    MeshManager& meshes;
    TextureManager& textures;
    SceneScope& scope;
    Input& input;
	PhysicsSystem& physics;
    SoundManager& sounds;
    AudioSystem& audio;

    // ---- Per-frame text overlay sink (owned by Application) ----
    std::vector<UITextDraw>& text;

    float dt = 0.0f;

	// ---- Skybox ������ ������ (SceneManager�� ����) ----
    TextureHandle* skybox = nullptr;

	// ---- Skybox helpers ----
    void SetSkybox(TextureHandle h)
    {
        if (!skybox) return;
        *skybox = h; // invalid�� ���� ȿ��
    }

    void ClearSkybox()
    {
        if (!skybox) return;
        *skybox = {};
    }

    // Cubemap (6-face) load
    Result<TextureHandle> LoadCubemapScoped(const std::array<std::string, 6>& utf8Paths);

    // ---- Unity-like helpers ----
    EntityId Instantiate(const std::string& name = "");

    void Destroy(EntityId e);    

	// �� ����Ʈ (���ҽ��� ����)
    Result<ModelAsset> ImportModel(const std::string& path, const ImportOptions& importOpt);

    // Import + Instantiate�� �� ����(������ ���� ���� ���� UX)
    Result<EntityId> SpawnModel(const std::string& path, const ImportOptions& importOpt, const SpawnModelOptions& spawnOpt);

    Result<EntityId> SpawnModel(const ModelAsset& asset, const SpawnModelOptions& spawnOpt);

    // �ؽ�ó �ε�
    Result<TextureHandle> LoadTextureScoped(const std::string& utf8Path);

    Result<TextureHandle> LoadTextureShared(const std::string& utf8Path);

    Result<SoundHandle> LoadSoundScoped(const std::string& utf8Path);

    Result<SoundHandle> LoadSoundShared(const std::string& utf8Path);

    void PlaySFX(SoundHandle clip, float volume = 1.0f, float pitch = 1.0f);

    void PlayBGM(SoundHandle clip, float volume = 1.0f);

    void StopBGM();

    // ---- Text overlay helpers (scene-friendly) ----
    void DrawText(float x, float y, const std::wstring& str,
                  float sizePx = 16.0f,
                  const DirectX::XMFLOAT4& color = DirectX::XMFLOAT4(1, 1, 1, 1),
                  const std::wstring& fontFamily = L"Segoe UI");

};
