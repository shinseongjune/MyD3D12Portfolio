#include "BulletComponent.h"
#include "SceneContext.h"
#include "PhysicsSystem.h"

void BulletComponent::Start(SceneContext& ctx)
{
	tr = &ctx.world.GetTransform(Entity());

	if (owner.IsValid())
	{
		const TransformComponent& ownerTr = ctx.world.GetTransform(owner);
		XMVECTOR q = XMLoadFloat4(&ownerTr.rotation);
		XMVECTOR f = XMVector3Rotate(XMVectorSet(0, 0, 1, 0), q);
		XMStoreFloat3(&direction, XMVector3Normalize(f));
	}
}

void BulletComponent::Update(SceneContext& ctx)
{
	Step(ctx);

	lifeTime -= ctx.dt;
	if (lifeTime <= 0.0f)
	{
		DestroyBullet(ctx);
	}
}

void BulletComponent::Step(SceneContext& ctx)
{
    // dir normalize
    XMVECTOR dirV = XMLoadFloat3(&direction);
    dirV = XMVector3Normalize(dirV);

    XMVECTOR posV = XMLoadFloat3(&tr->position);
    float dist = speed * ctx.dt;

    PhysicsSystem::RaycastHit hit{};

    uint32_t mask = 0xFFFFFFFFu;

    if (ctx.physics.Raycast(ctx.world, tr->position, direction, dist, hit, mask, false))
    {
        if (!owner.IsValid() || hit.entity != owner)
        {
            // ���� �������� ����
            tr->position = hit.point;

            // TODO: damage ó��

            DestroyBullet(ctx);
            return;
        }
    }

    // �̵�
    XMVECTOR newPosV = XMVectorAdd(posV, XMVectorScale(dirV, dist));
    XMStoreFloat3(&tr->position, newPosV);
}

void BulletComponent::DestroyBullet(SceneContext& ctx)
{
	ctx.world.RequestDestroy(Entity());
}
