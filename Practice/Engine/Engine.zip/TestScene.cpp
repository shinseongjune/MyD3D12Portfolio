#include "TestScene.h"

using namespace DirectX;

void TestScene::OnLoad(SceneContext& ctx)
{
    // =========================
    // 1. Import / Spawn �ɼ�
    // =========================
    ImportOptions importOpt{};
    importOpt.triangulate = true;
    importOpt.generateNormalsIfMissing = true;
    importOpt.flipV = true;          // �ؽ�ó ������ ����
    importOpt.uniformScale = 1.0f;   // �ʿ��ϸ� 0.01f ���� ������ ����

    SpawnModelOptions spawnOpt{};
    spawnOpt.name = "AlienAnimal";

    // 2) Instantiate
	auto spawned = ctx.SpawnModel("Assets/Alien Animal.obj", importOpt, spawnOpt);
    if (!spawned.IsOk())
    {
        LOG_ERROR("Failed to Spawn: %s", spawned.error->message.c_str());
        return;
    }
    EntityId root = spawned.value;

    // 2) �ؽ�ó �ε� (Assets/Texture/Alien-Animal-Base-Color.jpg)
    auto texRes = LoadTextureRGBA8_WIC("Assets/Texture/Alien-Animal-Base-Color.jpg",
        ImageColorSpace::SRGB, /*flipY=*/false);
    TextureHandle hTex{};
    if (texRes.IsOk())
    {
        hTex = ctx.textures.Create(std::move(texRes.value));
    }
    else
    {
        LOG_ERROR("Failed to load texture: %s", texRes.error->message.c_str());
        // hTex invalid -> �⺻ �ؽ�ó(slot0)�� ������
    }

    // 2.5) Material ����
    {
        // ���� submesh���� materialIndex�� �ٸ� �� ������ ������ �˳��� �����.
        uint32_t maxMatIndex = 256;

        MaterialComponent mat{};
        mat.slots.resize(maxMatIndex);

        // ������ "�� ���� �ؽ�ó"�� ��� ���Կ� �������� ����
        for (auto& s : mat.slots)
        {
            s.color = { 1,1,1,1 };
            s.albedo = hTex.IsValid() ? hTex : TextureHandle{ 0 };
        }

        ctx.world.AddMaterial(root, mat);
    }

    // =========================
    // 3. ��ġ/ȸ��/������ ����
    // =========================
	ctx.world.SetLocalPosition(root, { 0.f, 0.f, 0.f });
	ctx.world.SetLocalRotation(root, { 0.f, 0.f, 0.f, 1.f });
	ctx.world.SetLocalScale(root, { 1.f, 1.f, 1.f });


#if defined(_DEBUG)
    // ����׿�: primitive mesh ���� �׽�Ʈ
    {
        MeshCPUData boxMesh = PrimitiveMeshes::MakeUnitBox();
        MeshHandle boxHandle = ctx.meshes.Create(boxMesh);

        EntityId boxEntity = ctx.Instantiate("DebugBox");
        ctx.world.AddTransform(boxEntity);
        ctx.world.AddMesh(boxEntity, MeshComponent{ boxHandle });
        ctx.world.SetLocalPosition(boxEntity, { 0.f, 1.f, 0.f });

        MeshCPUData sphereMesh = PrimitiveMeshes::MakeUnitSphereUV(8, 16);
        MeshHandle sphereHandle = ctx.meshes.Create(sphereMesh);

		EntityId sphereEntity = ctx.Instantiate("DebugSphere");
        ctx.world.AddTransform(sphereEntity);
        ctx.world.AddMesh(sphereEntity, MeshComponent{ sphereHandle });
		ctx.world.SetLocalPosition(sphereEntity, { 2.f, 1.f, 0.f });

		ctx.world.SetParent(sphereEntity, boxEntity);
		ctx.world.SetParent(boxEntity, root);
    }
#endif

    // Camera
    {
		EntityId cam = ctx.Instantiate("MainCamera");

        ctx.world.AddTransform(cam);
        ctx.world.AddCamera(cam);

        ctx.world.SetLocalPosition(cam, { 0.f, 0.f, -6.f });
        ctx.world.GetCamera(cam).active = true;
    }
}

void TestScene::OnUnload(SceneContext& ctx)
{
}

void TestScene::OnUpdate(SceneContext& ctx)
{
    EntityId cam = ctx.world.FindActiveCamera();
    if (!ctx.world.IsAlive(cam)) return;

    auto& t = ctx.world.GetTransform(cam);

    const float speed = 3.0f * ctx.dt;

    XMFLOAT3 delta{ 0,0,0 };
    if (ctx.input.IsKeyDown(Key::W)) delta.z += speed;
    if (ctx.input.IsKeyDown(Key::S)) delta.z -= speed;
    if (ctx.input.IsKeyDown(Key::A)) delta.x -= speed;
    if (ctx.input.IsKeyDown(Key::D)) delta.x += speed;
    if (ctx.input.IsKeyDown(Key::Q)) delta.y -= speed;
    if (ctx.input.IsKeyDown(Key::E)) delta.y += speed;
	ctx.world.TranslateLocal(cam, delta);
}