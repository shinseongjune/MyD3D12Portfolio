#pragma once
#include <string>
#include "ImportRegistry.h"
#include "MeshManager.h"
#include "ModelAsset.h"
#include "World.h"
#include "EntityId.h"

struct SpawnModelOptions
{
    std::string name = "ImportedModel";
    bool spawnAsSingleEntity = true; // (����) true: 1 entity + ���� submesh ����
};

class AssetPipeline
{
public:
    AssetPipeline(ImportRegistry& registry, MeshManager& meshManager)
        : m_registry(registry), m_meshManager(meshManager) {
    }

    // 1) Import: ���� -> ModelAsset(���ҽ��� ����)
    Result<ModelAsset> ImportModel(
        const std::string& path,
        const ImportOptions& importOpt);

    // 2) Instantiate: ModelAsset -> World�� ��ƼƼ ����
    Result<EntityId> InstantiateModel(
        World& world,
        const ModelAsset& asset,
        const SpawnModelOptions& spawnOpt);

private:
    ImportRegistry& m_registry;
    MeshManager& m_meshManager;
};
