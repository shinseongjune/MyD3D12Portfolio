#pragma once

#include "MeshHandle.h"

struct MeshComponent
{
    MeshHandle mesh;
};
