#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <optional>

struct Float2 { float x, y; };
struct Float3 { float x, y, z; };
struct Float4 { float x, y, z, w; };

struct AABBBound
{
    Float3 min{ +1e30f, +1e30f, +1e30f };
    Float3 max{ -1e30f, -1e30f, -1e30f };
};

inline void ExpandAABB(AABBBound& b, const Float3& p)
{
    if (p.x < b.min.x) b.min.x = p.x;
    if (p.y < b.min.y) b.min.y = p.y;
    if (p.z < b.min.z) b.min.z = p.z;
    if (p.x > b.max.x) b.max.x = p.x;
    if (p.y > b.max.y) b.max.y = p.y;
    if (p.z > b.max.z) b.max.z = p.z;
}

// ������ ����ϴ� "CPU ���ؽ� ǥ��"
// (���߿� tangent/bitangent, color, joints/weights �� Ȯ��)
struct ImportedVertex
{
    Float3 position{};
    Float3 normal{ 0, 1, 0 };
    Float2 uv{ 0, 0 };
    Float4 tangent{ 1, 0, 0, 1 }; // xyz=tangent, w=handedness
};

struct ImportedSubmesh
{
    uint32_t startIndex = 0;
    uint32_t indexCount = 0;
    uint32_t materialIndex = 0;
    std::string name;
};

enum class ImageColorSpace : uint8_t
{
    Linear,
    SRGB
};

struct ImportedImageRef
{
    std::string uri;                 // ���� ���(���/����)
    ImageColorSpace colorSpace = ImageColorSpace::SRGB;
};

struct ImportedMaterial
{
    std::string name;

    Float4 baseColorFactor{ 1, 1, 1, 1 };
    std::optional<uint32_t> baseColorImage; // images[] �ε���

    // Ȯ��: normalImage, metallicRoughnessImage, emissiveImage ...
};

struct ImportedMesh
{
    std::string name;

    std::vector<ImportedVertex> vertices;
    std::vector<uint32_t> indices;
    std::vector<ImportedSubmesh> submeshes;

    AABBBound bounds{};
};

struct ImportedModel
{
    // ������ 1������ import�� ����� ��ü
    std::string sourcePath;
    std::vector<ImportedImageRef> images;
    std::vector<ImportedMaterial> materials;
    std::vector<ImportedMesh> meshes;
};

struct ImportOptions
{
    bool flipV = true;
    bool triangulate = true;

    bool generateNormalsIfMissing = true;
    bool generateTangentsIfMissing = false;

    float uniformScale = 1.0f;
};
