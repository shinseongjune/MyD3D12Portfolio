#include "AssetPipeline.h"
#include <DirectXMath.h>
#include "ImportTypes.h"

Result<ModelAsset> AssetPipeline::ImportModel(
    const std::string& path,
    const ImportOptions& importOpt)
{
    IAssetImporter* importer = m_registry.FindImporterForFile(path);
    if (!importer)
        return Result<ModelAsset>::Fail("No importer found for: " + path);

    auto imported = importer->Import(path, importOpt);
    if (!imported.IsOk())
        return Result<ModelAsset>::Fail(imported.error->message);

    const ImportedModel& model = imported.value;
    if (model.meshes.empty())
        return Result<ModelAsset>::Fail("Imported model has no meshes: " + path);

    ModelAsset out{};
    out.sourcePath = model.sourcePath.empty() ? path : model.sourcePath;
    out.meshes.reserve(model.meshes.size());

    for (const auto& mesh : model.meshes)
    {
        // ImportedMesh -> MeshCPUData ��ȯ
        MeshCPUData cpu{};
        cpu.positions.reserve(mesh.vertices.size());
		cpu.uvs.reserve(mesh.vertices.size());
        for (const auto& v : mesh.vertices)
        {
            cpu.positions.push_back(DirectX::XMFLOAT3(v.position.x, v.position.y, v.position.z));
			cpu.uvs.push_back(DirectX::XMFLOAT2(v.uv.x, v.uv.y));
        }

        cpu.indices.reserve(mesh.indices.size());
        for (uint32_t idx : mesh.indices)
        {
            if (idx > 0xFFFFu)
                return Result<ModelAsset>::Fail("Mesh has index > 65535 (uint16 overflow). Need 32-bit index support.");
            cpu.indices.push_back((uint16_t)idx);
        }

        MeshHandle h = m_meshManager.Create(cpu);

        // ����� color��: ���� ��Ģ �״��
        DirectX::XMFLOAT4 color{ 1.f, 1.f, 1.f, 1.f };
        if (!model.materials.empty())
        {
            uint32_t mi = 0;
            if (!mesh.submeshes.empty())
                mi = mesh.submeshes[0].materialIndex;

            if (mi < (uint32_t)model.materials.size())
            {
                const auto& m = model.materials[mi];
                color = DirectX::XMFLOAT4(
                    m.baseColorFactor.x, m.baseColorFactor.y,
                    m.baseColorFactor.z, m.baseColorFactor.w
                );
            }
        }

        ModelAssetMesh am{};
        am.name = mesh.name.empty() ? "Mesh" : mesh.name;
        am.mesh = h;
        am.baseColor = color;
        out.meshes.push_back(std::move(am));
    }

    return Result<ModelAsset>::Ok(std::move(out));
}

Result<EntityId> AssetPipeline::InstantiateModel(
    World& world,
    const ModelAsset& asset,
    const SpawnModelOptions& spawnOpt)
{
    if (asset.meshes.empty())
        return Result<EntityId>::Fail("ModelAsset has no meshes.");

    EntityId root = world.CreateEntity(spawnOpt.name);
    world.AddTransform(root);

    // ���� ����: MeshComponent�� mesh 1���� �����ϱ� �ڽ����� �ɰ�(������ ����)
    for (const auto& m : asset.meshes)
    {
        EntityId e = world.CreateEntity(m.name);
        world.AddTransform(e);
        world.SetParent(e, root);

        world.AddMesh(e, MeshComponent{ m.mesh });
        world.AddMaterial(e);
        world.GetMaterial(e).color = m.baseColor;
    }

    return Result<EntityId>::Ok(root);
}
