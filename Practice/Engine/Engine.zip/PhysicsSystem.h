#pragma once
#include "World.h"
#include "PhysicsTypes.h"
#include <unordered_map>
#include <cstdint>
#include <vector>
#include <utility>

class PhysicsSystem
{
public:
    void Step(World& world, float dt);

    void SetGravity(const XMFLOAT3& g) { m_gravity = g; }
    void SetIterations(int it) { m_iterations = it; }

    void SetGravityEnabled(bool enabled) { m_gravityEnabled = enabled; }
    bool IsGravityEnabled() const { return m_gravityEnabled; }

private:
    XMFLOAT3 m_gravity{ 0.0f, -9.81f, 0.0f };
    int m_iterations = 10; // solver �ݺ�
    bool m_gravityEnabled = true;

    // --- pipeline stages ---
    void Integrate(World& world, float dt);
    void BuildPairs(World& world, std::vector<std::pair<EntityId, EntityId>>& outPairs);
    void Narrowphase(World& world, const std::vector<std::pair<EntityId, EntityId>>& pairs, std::vector<std::tuple<EntityId, EntityId, Contact>>& outContacts);

    void Solve(World& world, std::vector<std::tuple<EntityId, EntityId, Contact>>& contacts, float dt);

    // --- helpers ---
    AABB ComputeWorldAABB(const World& world, EntityId e) const;
    bool LayerMatch(const ColliderComponent& a, const ColliderComponent& b) const;

    bool Collide_SphereSphere(const World& world, EntityId a, EntityId b, Contact& out) const;
    bool Collide_AABBAABB(const AABB& a, const AABB& b, Contact& out) const;
    bool Collide_SphereAABB(const XMFLOAT3& c, float r, const AABB& b, Contact& out) const;

    // Collision Events
    std::unordered_map<uint64_t, std::pair<EntityId, EntityId>> m_prevPairs;

    void EmitCollisionEvents(World& world, const std::vector<std::tuple<EntityId, EntityId, Contact>>& contacts);

	// Sequencial Impulses�� ����Ʈ ĳ��
    struct CachedContact
    {
        XMFLOAT3 normal{};
        XMFLOAT3 point{};
        float normalImpulseSum = 0.0f;
        float tangentImpulseSum = 0.0f;
    };

    std::unordered_map<uint64_t, CachedContact> m_contactCache;

    void WarmStart(World& world, std::vector<std::tuple<EntityId, EntityId, Contact>>& contacts);
    void StoreContactCache(const std::vector<std::tuple<EntityId, EntityId, Contact>>& contacts);
    void UpdateSleep(World& world, float dt);

private:
    void DebugDrawColliders(World& world, const std::vector<std::tuple<EntityId, EntityId, Contact>>& contacts);
    void DrawAABB(const AABB& aabb, const DirectX::XMFLOAT4& color);
};